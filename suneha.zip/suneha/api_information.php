<html>
<body>
<font color="#3D3D3D"><b><p style="font-family:Helvetica; font-size:14px;">Here are the few Guidelines</p></b></font>
<list>
<li> Send messages via this website. </li>



<li><p style="font-family:Helvetica; font-size:12px;">You can download <a href="http://202.164.53.122/~navdeep/suneha.tar.gz"> FosMIN plugin </a>in the form of SMS API.</p></li>



</list> 

</body>
</html>
