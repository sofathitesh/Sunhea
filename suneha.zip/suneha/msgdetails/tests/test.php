<?php

/**
 * Tutoriel file
 * Description : Simple substitutions of variables
 * You need PHP 5.2 at least
 * You need Zip Extension or PclZip library
 *
 * @copyright  GPL License 2008 - Julien Pauli - Cyril PIERRE de GEYER - Anaska (http://www.anaska.com)
 * @license    http://www.gnu.org/copyleft/gpl.html  GPL License
 * @version 1.3
 */

require_once('../library/odf.php');

$odf = new odf("message.odt");
$getdata=$_GET['id'];
// Database Connection
$con = mysqli_connect("localhost","root","expDB1","navdeep"); 
// My work
$article = $odf->setSegment('articles');
$result = mysqli_query($con,"SELECT receiver,msgdata FROM send_sms WHERE id=$getdata");
while($row = mysqli_fetch_array($result))
{
	$article->numArticle($row['receiver']);
	$article->msgArticle($row['msgdata']);
    $article->merge();		
}	

$odf->mergeSegment($article);
// We export the file
$odf->exportAsAttachedFile();
 
?>
