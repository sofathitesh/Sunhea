<html>
<body>

<li>You can <a class="ab-item" href="http://localhost/wp/">Visit Site</a> to send SMS.  </li>
<li>You can also use API to embed it in your webpage.   </li>



</body>
</html>
